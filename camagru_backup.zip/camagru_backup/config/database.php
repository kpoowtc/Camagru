<?php

$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "546524266980614";
$DB_NAME = "camagru";

?>



