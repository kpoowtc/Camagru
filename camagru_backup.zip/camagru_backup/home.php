<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="css/styles.css">
</head>
<body background="https://media.giphy.com/media/l2Sqf1fbj1qrmaJ6E/giphy.gif">

<div class="topnav">
  <div class="login-container">
    <form action="functionalities/gallery/gallery.php" method="post">
      <button type="submit" name="gallery-btn">Gallery</button>
    </form>
  </div>
  <div class="login-container">
    <form action="functionalities/camera.php" method="post">
      <button type="submit" name="camera-btn">Camera</button>
    </form>
  </div>
  <div class="login-container">
    <form action="logout.php" method="post">
      <button type="submit" name="logout-submit">Logout</button>
    </form>
  </div>
  <div class="login-container">
  <form action="functionalities/upload.inc.php" method="post">
  <button type="submit" name="upload-btn">Upload</button>
  </form>
  </div>
  <div class="login-container">
    <form action="functionalities/changedetails.php" method="post">
      <button type="submit" name="logout-submit">Edit User Info</button>
    </form>
  </div>
  <a class="active" href="home.php">Camagru</a>
  </div>
</div>

<div>
  <div class="img">
      <div class="row">
        <img src="images/logo2.png" alt="logo" width="802px" height="360px">
      </div>
      <br><br><br><br>
      <main>
    </main>
  </div>
</div>

</body>
</html>