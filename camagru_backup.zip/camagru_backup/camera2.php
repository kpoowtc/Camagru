<?php
session_start();
if (!$_SESSION['user_name'] && !$_SESSION['user_id'] && !$_SESSION['user_email'] )
{
    header('Location:index.php');
}
//echo "Welcome ".$_SESSION['user_name']. "<br/>";
?>
<html>
    <head>
    <style>
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}
</style>
</head>
    <header>
    <div>
        <a href = "index.php">Gallery</a>
        <a href = "userprofile.php">Edit Profile</a>
        <a href = "signout.php">Sign Out</a>
    </div>
    </header>
    <body>
        <div class = "container">
            <div class = "main">
                <div class = "div-sticker">
                    <select name="stickers" id="stickers">
                        <option value="none">Default</option>
                        <option value="laugh.jpg">laugh _emoji</option>
                        <option value="loveyou.jpg">love_you</option>
                        <option value="tounge_out.jpg">tounge_out_emoji</option>
                        <option value="whatsapp.jpg">whatsapp</option>
                    </select>
                </div>
                <div class = "preview">
                    <video autoplay id = "play"></video>
                    <img id = 'chosen-img' width="250px" height="250px"/>
                    <input type="text" id = 'sticker-name' style = "display:none" value = "none"/>
                    <canvas width = "400" height = "400" id="main"></canvas>
                </div>
                <div id = "Pick" class = "capture-btn">
                        <input id = "choose" type="file" name="picture" accept = "*/images"/>
                    <button type="button" id = "capture">capture</button>
                </div>
            </div>
            <div class = "side">
                <?php
                    $img_dir = "uploads/";
                    $images = scandir($img_dir);
                    $images = preg_grep('~^'.$_SESSION['user_name'].'.*\.png$~', $images);
                    $list = '<ul id = "list-side">';
                    foreach($images as $img) 	
                    { 
                        if($img === '.' || $img === '..')
                        {
                            continue;
                        } 
                        if (preg_match("/\.(gif|jpg|png|jpeg)$/i",$img))
                        {				
                            $list.='<li id = "'.$img.'" class="li-img"><div class = "gallery">
                                        <img onmousedown="removeImage(event)" src=" '.$img_dir.$img.'" width="600px" height="400px" />
                                        </div>
                                    </li>';
                        } 
                        else 
                        { 
                            continue; 
                        }	
                    }
                    $list .= '</ul>';
                    echo $list; 
                ?> 
            </div>
        </div>
       
        <script src = "camera.js"></script> 
        <footer>
    <div class="footer">
    <p>&copy; 2019 Camagru<p>
    </div>
</footer>         
    </body>
</html>