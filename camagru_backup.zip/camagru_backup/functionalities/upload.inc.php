<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<link rel="stylesheet" href="../css/styles.css">
<title>Upload</title>
</head>
<body>
    <div class="topnav">
    <div class="login-container">
    <form action="gallery/gallery.php" method="post">
      <button type="submit" name="gallery-btn">Gallery</button>
    </form>
  </div>
  <div class="login-container">
    <form action="Camera.php" method="post">
      <button type="submit" name="camera-btn">Camera</button>
    </form>
  </div>
  <div class="login-container">
    <form action="logout.php" method="post">
      <button type="submit" name="logout-submit">Logout</button>
    </form>
  </div>
  <div class="login-container">
    <form action="changedetails.php" method="post">
      <button type="submit" name="logout-submit">Edit User Info</button>
    </form>
  </div>
  <a class="active" href="../home.php">Camagru</a>
        
    </div>
</div>
<div class="img">
      <div class="row">
        <img src="../images/logo2.png" alt="logo">
      </div>
</div>

<div class="container">
  <div class="row">
    <div class="col-md-4 offset-md-4 form-div">
    <form action="upload.php" method="post" enctype="multipart/form-data">

    <?php if(count($uploadErrors) > 0): ?>
          <div class="alert alert-danger">
            <?php foreach($uploadErrors as $uploadError): ?>
            <li><?php echo $uploadError; ?></li>
            <?php endforeach; ?>
          </div>
    <?php endif; ?>

    Select image to upload:
    <div class="form-group">
        <input type="file" name="fileToUpload" id="fileToUpload">
    </div>
    <div class="form-group">
        <input type="submit" value="Upload Image" name="submit">
    </div>
</form>
    </div>
  </div>
</div>
</body>
</html>