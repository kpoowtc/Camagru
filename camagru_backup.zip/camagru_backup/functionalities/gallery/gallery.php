<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
  div.gallery {
  margin: 5px;
  border: 3px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}
  .btn_new {
  background-color:#2196F3;
  border: none;
  color: white;
  padding: 27px 16px;
  font-size: 18px;
  cursor: pointer;
  border-radius: 50%;
}
.btn_fb {
  background-color:#2196F3;
  border: none;
  color: white;
  padding: 5px 16px;
  font-size: 25px;
  cursor: pointer;
  border-radius: 50%;
}
.btn_ig {
  background-color:pink;
  border: none;
  color: white;
  padding: 5px 16px;
  font-size: 25px;
  cursor: pointer;
  border-radius: 50%;
}
.btn_new:hover {
  background-color: Gray;
}

/* Popup container - can be anything you want */
.popup {
  position: relative;
  display: inline-block;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* The actual popup */
.popup .popuptext {
  visibility: hidden;
  width: 160px;
  background-color: #555;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 8px 0;
  position: absolute;
  z-index: 1;
  bottom: 125%;
  left: 50%;
  margin-left: -80px;
}

/* Popup arrow */
.popup .popuptext::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  margin-left: -5px;
  border-width: 5px;
  border-style: solid;
  border-color: #555 transparent transparent transparent;
}

/* Toggle this class - hide and show the popup */
.popup .show {
  visibility: visible;
  -webkit-animation: fadeIn 1s;
  animation: fadeIn 1s;
}

/* Add animation (fade in the popup) */
@-webkit-keyframes fadeIn {
  from {opacity: 0;} 
  to {opacity: 1;}
}

@keyframes fadeIn {
  from {opacity: 0;}
  to {opacity:1 ;}
}
</style>
<link rel="stylesheet" href="../../css/styles.css">
<title>Edit User Info</title>
</head>
<body>
    <div class="topnav">
      <div class="login-container">
        <form action="logout.php" method="post">
          <button type="submit" name="logout-submit">Logout</button>
        </form>
      </div>
      <div class="login-container">
        <form action="../camera.php" method="post">
          <button type="submit" name="camera-btn">Camera</button>
        </form>
      </div>
      <div class="login-container">
        <form action="../upload.inc.php" method="post">
          <button type="submit" name="upload-btn">Upload</button>
        </form>
      </div>
        <div class="login-container">
          <form action="../changedetails.php" method="post">
          <button type="submit" name="logout-submit">Edit User Info</button>
          </form>
        </div>
  <a class="active" href="../../home.php">Camagru</a>
        
    </div>
</div>
<div class="img">
      <div class="row">
        <img src="../../images/logo2.png" alt="logo">
      </div>
</div>

<!-- <div class="gallery">
        <a>
        <img src="../uploads/astronaut-man-person-39651.jpg" width="600" height="400"/><br />;
        </a>
        <div class="desc">Add a description of the image here</div>
        <button class="btn"><i class="fa fa-heart"></i></button>
</div> -->
<?php
$dirname = "../uploads/";
$images = glob($dirname."*.jpg");

foreach ($images as $image){
  echo    '<div class="container">';
  echo    '<div class="col-md-9 offset-md-9 form-div">';
  echo    '<img src="'.$image.'" width="600" height="400"/><br/>';
  echo '<div class="form-group">
      <button class="btn_new"><i class="fa fa-heart"></i>Like</button>
      
      <div class="popup" onclick="myFunction()">
      <button class="btn_new"><i class="fa fa-share"></i>Share</button>

        <span class="popuptext" id="myPopup">
        Share on:<br/>

          <button class="btn_fb" onclick="fb()"><i class="fa fa-facebook"></i></button>

          <button class="btn_ig" onclick="ig()"><i class="fa fa-instagram"></i></button>

        <button class="btn_fb" onclick="twitter()"><i class="fa fa-twitter"></i></button>

        </span>
    </div>
      </div>';
        echo '<div class="form-group">
        <input id="comment" type="text" name="comment" value="Type your comment" class="form-control form-control-lg">
      </div><br>';
      echo '<div>
      <button type="submit" name="comment-btn" class="btn btn-primary btn-block btn-lg">Comment</button>
</div><br>';
  echo    "</div>";
  echo    "</div>";
}
// foreach($images as $image) {
// echo '<div class="gallery">
//         <a>
//         <img src="'.$image.'" width="600" height="400"/><br />;
//         </a>
//   <button class="btn"><i class="fa fa-heart"></i></button>
//       </div>';
// }
?>

<script>
// When the user clicks on div, open the popup
function myFunction() {
  var popup = document.getElementById("myPopup");
  popup.classList.toggle("show");
}
function fb() {
  location.replace("https://www.facebook.com")
}
function ig() {
  location.replace("https://www.instagram.com")
}
function twitter() {
  location.replace("https://www.twitter.com")
}
</script>
</body>
</html>