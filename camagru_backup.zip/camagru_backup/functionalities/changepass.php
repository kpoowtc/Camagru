<?php
    require '../config/connection.php';
    include ("../config/database.php");
    session_start();
    if (!$_SESSION['username'] && !$_SESSION['user_id'] && !$_SESSION['email'] ){
        header('Location:../../home.php');
    }

    if (isset($_POST['update-btn'])){
      $errors = array();
      $msg = "";
      $user_id = $_SESSION['user_id'];
      $old_pass = $_POST['old_pass'];
      $new_pass = $_POST['new_pass'];
      $mailreceiver = $_POST['receive_email'];

      if (empty($new_pass) && empty($old_pass) && empty($mailreceiver)){
        $errors['all'] = "Empty fields, fill all fields";
      }else{
          if (empty($old_pass)){
            $errors['old_pass'] = "Old Password required";
          if (empty($mailreceiver)){
            $errors['receive_email'] = "Choose to receive email or not!";
          }
          if (empty($new_pass)){
              $errors['new_pass'] = "New Password required";
          }elseif(!$upper || !$lower || !$number || !$specialChars || strlen($new_pass) < 8) {
              $errors['password'] = "Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.";
          }

        //checking if old pass matches old pass
        $old_pass = md5($old_pass);
        $new_pass = md5($new_pass);
        //validation - checking if email or username already exists
        $conn = connection();
        $userQ = "SELECT * FROM users WHERE password=:old_pass LIMIT 1";
        $stmt = $conn->prepare($userQ);
        $stmt->execute(array(':old_pass'=>$old_pass));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (($stmt->rowCount() <= 0)){
          $errors['old_pass'] = "Incorrect Old Password";
        }
      }
    }
      if (count($errors) === 0){
      try{
          $conn = connection();
          $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          $query = "UPDATE users SET password = :new_password WHERE user_id = :user_id";
          $sql = $conn->prepare($query);
          $sql->execute(array(':new_password'=>$new_pass,':user_id'=>$user_id));
          if ($sql->rowCount()){
            header("Location: changepass.php");
            $msg = "Profile Updated";

            //send email
            $to      = "kpoo.main@gmail.com";
            $subject = 'Change Of Password';
            $message = "
            Your password has been changed to: $new_password
            
            If this wasn't you, you're advised to change your login credentials.
            Log on to your application and navigate to 'Edit User Info'";
            $headers =  'From: Camagru' . "\r\n"
            .'X-Mailer: PHP/' . phpversion();
            
            if (mail($to, $subject, $message, $headers)){
                echo "Email Sent";
            }else{
                echo "Email Not Sent";
            }
          }
        }catch(PDOException $e){
          echo " Error".$e->getMessage();
        }
      }
  }
// }
?>
  
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<link rel="stylesheet" href="../css/styles.css">
<title>Edit User Info</title>
</head>
<body>
    <div class="topnav">
    <div class="login-container">
    <form action="gallery/gallery.php" method="post">
      <button type="submit" name="gallery-btn">Gallery</button>
    </form>
  </div>
  <div class="login-container">
    <form action="camera.php" method="post">
      <button type="submit" name="camera-btn">Camera</button>
    </form>
  </div>
  <div class="login-container">
    <form action="logout.php" method="post">
      <button type="submit" name="logout-submit">Logout</button>
    </form>
  </div>
  <div class="login-container">
  <form action="upload.inc.php" method="post">
  <button type="submit" name="upload-btn">Upload</button>
  </form>
  </div>
  <a class="active" href="../home.php">Camagru</a>
        
    </div>
</div>
<div class="img">
      <div class="row">
        <img src="../images/logo2.png" alt="logo">
      </div>
</div>

<div class="container">
  <div class="row">
    <div class="col-md-4 offset-md-4 form-div">
      <form action="changepass.php" method="post">

      <?php if((count($errors) === 0) && !(empty($msg))): ?>
          <div class="alert alert-success">
            <li><?php echo $msg; ?></li>
          </div>
      <?php endif; ?>

      <?php if(count($errors) > 0): ?>
          <div class="alert alert-danger">
            <?php foreach($errors as $error): ?>
            <li><?php echo $error; ?></li>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <h3 class="text-center">Change Password</h3>

        <div class="form-group">
          <label>Old Password</label>
          <input type="password" name="old_pass" class="form-control form-control-lg">
        </div><br>

        <div class="form-group">
          <label>New Password</label>
          <input type="password" name="new_pass" class="form-control form-control-lg">
        </div><br>

        <p>Receive Email Notification?</p>
             Yes <input type="radio" name="receive_email" value="Yes"><? if ($_SESSION['receive_email'] == "Yes") echo " checked"; ?>
             No <input type="radio" name="receive_email" value="No"><? if ($_SESSION['receive_email'] == "No") echo " checked"; ?><br>
             <br/>
             
        <div>
          <button type="submit" name="update-btn" class="btn btn-primary btn-block btn-lg">Update</button>
        </div><br>
      </form>
    </div>
  </div>
</div>
</body>
</html>