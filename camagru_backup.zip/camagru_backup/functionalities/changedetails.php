<?php
    require '../config/connection.php';
    include ("../config/database.php");
    session_start();
    if (!$_SESSION['username'] && !$_SESSION['user_id'] && !$_SESSION['email'] ){
        header('Location:../../home.php');
    }

    if (isset($_POST['update-btn'])){
      $errors = array();
      $msg = "";
      $user_id = $_SESSION['user_id'];
      $username = $_POST['username'];
      $email = $_POST['email'];
      $mailreceiver = $_POST['receive_email'];

      if (empty($username) && empty($email) && empty($mailreceiver)){
        $errors['all'] = "Empty fields, fill all fields";
      }else{
          if (empty($username)){
              $errors['username'] = "Username required";
          }elseif(!preg_match("/^[a-zA-Z0-9]*$/",$username)){
              $errors['username'] = "Invalid Username";
          }
          if (empty($email)){
              $errors['email'] = "Email required";
          }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)){
              $errors['email'] = "Email address in invalid";
          }
          if (empty($mailreceiver)){
              $errors['receive_email'] = "Choose to receive email or not!";
          }
      }

      //validation - checking if username already exists
      $conn = connection();
      $usernameQ = "SELECT * FROM users WHERE username=:username && user_id!=:user_id LIMIT 1";
      $stmt = $conn->prepare($usernameQ);
      $stmt->execute(array(":username"=>$username, ":user_id"=>$user_id));
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
      if ($stmt->rowCount() > 0){
          $errors['username'] = "Username already exists";
      }

      //validation - checking if email already exists
      $conn = connection();
      $emailQ = "SELECT * FROM users WHERE email=:email && user_id!=:user_id LIMIT 1";
      $stmt = $conn->prepare($emailQ);
      $stmt->execute(array(":email"=>$email, ":user_id"=>$user_id));
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      
      if ($stmt->rowCount() > 0){
          $errors['email'] = "Email already exists";
      }

      if (count($errors) === 0){
      try{
          $conn = connection();
          $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          $query = "UPDATE users SET username = :username, receive_email = :receive_email, email = :email WHERE user_id = :user_id";
          $sql = $conn->prepare($query);
          $sql->execute(array(':username'=>$username, ':email'=>$email, 'receive_email'=>$mailreceiver, ':user_id'=>$user_id));
          if ($sql->rowCount()){
            $_SESSION['username'] = $username;
            $_SESSION['email'] = $email;
            header("Location: changedetails.php");
            $msg = "Profile Updated";

            //send email
            $to      = "kpoo.main@gmail.com";
            $subject = 'Change Of User Info';
            $message = "
            Your user info has been changed:
            Username : $username
            Email : $email
            Receive Emails: $mailreceiver
            
            If this wasn't you, you're advised to change your password.
            Log on to your application and navigate to 'Edit User Info'";
            $headers =  'From: Camagru' . "\r\n"
            .'X-Mailer: PHP/' . phpversion();
            
            if (mail($to, $subject, $message, $headers)){
                echo "Email Sent";
            }else{
                echo "Email Not Sent";
            }
          }
      }catch(PDOException $e){
          echo " Error".$e->getMessage();
      }
    }
  }
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<link rel="stylesheet" href="../css/styles.css">
<title>Edit User Info</title>
</head>
<body>
    <div class="topnav">
    <div class="login-container">
    <form action="gallery/gallery.php" method="post">
      <button type="submit" name="gallery-btn">Gallery</button>
    </form>
  </div>
  <div class="login-container">
    <form action="camera.php" method="post">
      <button type="submit" name="camera-btn">Camera</button>
    </form>
  </div>
  <div class="login-container">
    <form action="logout.php" method="post">
      <button type="submit" name="logout-submit">Logout</button>
    </form>
  </div>
  <div class="login-container">
  <form action="upload.inc.php" method="post">
  <button type="submit" name="upload-btn">Upload</button>
  </form>
  </div>
  <a class="active" href="../home.php">Camagru</a>
        
    </div>
</div>
<div class="img">
      <div class="row">
        <img src="../images/logo2.png" alt="logo">
      </div>
</div>

<div class="container">
  <div class="row">
    <div class="col-md-4 offset-md-4 form-div">
      <form action="changedetails.php" method="post">

      <?php if((count($errors) === 0) && !(empty($msg))): ?>
          <div class="alert alert-success">
            <li><?php echo $msg; ?></li>
          </div>
      <?php endif; ?>

      <?php if(count($errors) > 0): ?>
          <div class="alert alert-danger">
            <?php foreach($errors as $error): ?>
            <li><?php echo $error; ?></li>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <h3 class="text-center">Edit User Info</h3>

        <div class="form-group">
          <label for="usernameChange">Username</label>
          <input type="text" name="username" class="form-control form-control-lg">
          <!-- <input id="usernameChange" type="text" name="usernameChange" class="form-control form-control-lg"> -->
        </div><br>
        <div class="form-group">
          <label for="emailChange">Email</label>
          <input type="text" name="email" class="form-control form-control-lg">
          <!-- <input id="emailChange" type="text" name="emailChange" class="form-control form-control-lg"> -->
        </div><br>
        <p>Receive Email Notification?</p>
             Yes <input type="radio" name="receive_email" value="Yes"><? if ($_SESSION['receive_email'] == "Yes") echo " checked"; ?>
             No <input type="radio" name="receive_email" value="No"><? if ($_SESSION['receive_email'] == "No") echo " checked"; ?><br>
             <br/>
        <div>
          <button type="submit" name="update-btn" class="btn btn-primary btn-block btn-lg">Update</button>
          <p><a href = "changepass.php">change password</a></p>
        </div><br>
      </form>
    </div>
  </div>
</div>
</body>
</html>