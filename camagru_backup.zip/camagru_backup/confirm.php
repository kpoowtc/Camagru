<?php

session_start();

require 'config/connection.php';
include ("config/database.php");

$verifMessage = "";

function redirect(){
    header('location: signin.php');
}

function verif(){
    echo "Verified Successfully";
}

if (!isset($_GET['email']) || !isset($_GET['token'])){
    redirect();
} else{
    $conn = connection();

    $token = $_GET['token'];
    $email = $_GET['email'];
    $empToken = '';
    
    echo $token;
    echo $email;

    $verified = 1;

    try{
        //updating verified
        $sql = "UPDATE users SET verified=:verified WHERE token=:token";
        $stmt = $conn->prepare($sql);
        $stmt->execute(array(":token"=>$token, ":verified"=>$verified));

        //updating token
        $sql = "UPDATE users SET token=:token WHERE email=:email";
        $stmt = $conn->prepare($sql);
        $stmt->execute(array(":token"=>$empToken, ":email"=>$email));

        //set message
        // $verifMessage = "Verified Successfully";
        // $class = "alert alert-success";
        //redirecting
        redirect();
    } catch(PDOException $e){
        die("ERROR: Could not able to execute $sql. " . $e->getMessage());
    }
    // if (($stmt->rowCount() > 0){
    //     $sql = "UPDATE users SET verified=1 WHERE email=$email AND token=$token";
    //     $stmt->$conn->prepare($sql);
    //     $stmt->execute();
    //     echo $stmt->rowCount() . " records UPDATED successfully";
    // }
}